package br.ufpb.pessoa;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class PessoaTest {
    @Test
    public void testaConstrutores (){
        Pessoa p = new Pessoa();
        assertTrue(p.getNome().equals(""));
        assertTrue(p.getIdade()==0);

    }

}
