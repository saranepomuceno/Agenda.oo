package br.ufpb.pessoa;

import java.util.*;

public class TestaPessoa {
    public static void main (String[] args) {
        ArrayList<Pessoa> pessoas = new ArrayList<>();
        for (int i = 0; i <5;i++) {
            Scanner leitor = new Scanner(System.in);
            String nome = leitor.nextLine();
            int idade = Integer.parseInt(leitor.nextLine());
            Pessoa pessoa = new Pessoa(nome, idade);
            pessoas.add(pessoa);
        }
        for (Pessoa p: pessoas){
            if (p.ehDeMaior()){
                System.out.println(p.getNome()+ " é de maior");
            }else{
                System.out.println(p.getNome() + " é de menor");
            }
        }
    }
}
